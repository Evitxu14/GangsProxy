package com.zenith.discord;

import com.zenith.Proxy;
import com.zenith.event.chat.DeathMessageChatEvent;
import com.zenith.event.client.*;
import com.zenith.event.module.*;
import com.zenith.event.player.*;
import com.zenith.event.plugin.PluginLoadFailureEvent;
import com.zenith.event.plugin.PluginLoadedEvent;
import com.zenith.event.queue.QueueCompleteEvent;
import com.zenith.event.queue.QueuePositionUpdateEvent;
import com.zenith.event.queue.QueueStartEvent;
import com.zenith.event.server.ServerPlayerConnectedEvent;
import com.zenith.event.server.ServerPlayerDisconnectedEvent;
import com.zenith.event.server.ServerRestartingEvent;
import com.zenith.event.update.UpdateAvailableEvent;
import com.zenith.event.update.UpdateStartEvent;
import com.zenith.feature.api.fileio.FileIOApi;
import com.zenith.feature.player.World;
import com.zenith.feature.queue.Queue;
import com.zenith.module.impl.AntiAFK;
import com.zenith.module.impl.SessionTimeLimit;
import com.zenith.util.ChatUtil;
import com.zenith.util.DisconnectReasonInfo;
import com.zenith.util.math.MathHelper;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.components.buttons.Button;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.zenith.Lang;
import static com.github.rfresh2.EventConsumer.of;
import static com.zenith.Globals.*;
import static com.zenith.command.impl.StatusCommand.getCoordinates;
import static com.zenith.discord.DiscordBot.*;
import static com.zenith.util.math.MathHelper.formatDuration;
import static java.util.Arrays.asList;
import static java.util.Objects.nonNull;

public class NotificationEventListener {
    public static final NotificationEventListener INSTANCE = new NotificationEventListener();

    private NotificationEventListener() {}

    public void subscribeEvents() {
        EVENT_BUS.subscribe(
            this,
            of(ClientConnectEvent.class, this::handleConnectEvent),
            of(ClientOnlineEvent.class, this::handlePlayerOnlineEvent),
            of(ClientConfigurationEvent.Entering.class, this::handleClientConfigurationEnteringEvent),
            of(ClientDisconnectEvent.class, this::handleDisconnectEvent),
            of(QueuePositionUpdateEvent.class, this::handleQueuePositionUpdateEvent),
            of(QueueWarningEvent.class, this::handleQueueWarning),
            of(AutoEatOutOfFoodEvent.class, this::handleAutoEatOutOfFoodEvent),
            of(QueueCompleteEvent.class, this::handleQueueCompleteEvent),
            of(QueueStartEvent.class, this::handleStartQueueEvent),
            of(ClientDeathEvent.class, this::handleDeathEvent),
            of(ClientDeathMessageEvent.class, this::handleSelfDeathMessageEvent),
            of(HealthAutoDisconnectEvent.class, this::handleHealthAutoDisconnectEvent),
            of(PlayerConnectedEvent.class, this::handleProxyClientConnectedEvent),
            of(PlayerConnectedEvent.class, this::handleProxyClientConnectedEventCheck2b2tMCVersionMatch),
            of(SpectatorConnectedEvent.class, this::handleProxySpectatorConnectedEvent),
            of(PlayerDisconnectedEvent.class, this::handleProxyClientDisconnectedEvent),
            of(VisualRangeEnterEvent.class, this::handleVisualRangeEnterEvent),
            of(VisualRangeLeaveEvent.class, this::handleVisualRangeLeaveEvent),
            of(VisualRangeLogoutEvent.class, this::handleVisualRangeLogoutEvent),
            of(NonWhitelistedPlayerConnectedEvent.class, this::handleNonWhitelistedPlayerConnectedEvent),
            of(BlacklistedPlayerConnectedEvent.class, this::handleBlacklistedPlayerConnectedEvent),
            of(SpectatorDisconnectedEvent.class, this::handleProxySpectatorDisconnectedEvent),
            of(ActiveHoursConnectEvent.class, this::handleActiveHoursConnectEvent),
            of(DeathMessageChatEvent.class, this::handleDeathMessageChatEventKillMessage),
            of(ServerPlayerConnectedEvent.class, this::handleServerPlayerConnectedEventStalk),
            of(ServerPlayerDisconnectedEvent.class, this::handleServerPlayerDisconnectedEventStalk),
            of(UpdateStartEvent.class, this::handleUpdateStartEvent),
            of(ServerRestartingEvent.class, this::handleServerRestartingEvent),
            of(ClientLoginFailedEvent.class, this::handleProxyLoginFailedEvent),
            of(ClientStartConnectEvent.class, this::handleStartConnectEvent),
            of(PrioStatusUpdateEvent.class, this::handlePrioStatusUpdateEvent),
            of(AutoReconnectEvent.class, this::handleAutoReconnectEvent),
            of(MsaDeviceCodeLoginEvent.class, this::handleMsaDeviceCodeLoginEvent),
            of(UpdateAvailableEvent.class, this::handleUpdateAvailableEvent),
            of(ReplayStartedEvent.class, this::handleReplayStartedEvent),
            of(ReplayStoppedEvent.class, this::handleReplayStoppedEvent),
            of(PlayerTotemPopAlertEvent.class, this::handleTotemPopEvent),
            of(NoTotemsEvent.class, this::handleNoTotemsEvent),
            of(PluginLoadFailureEvent.class, this::handlePluginLoadFailure),
            of(PluginLoadedEvent.class, this::handlePluginLoadedEvent),
            of(SpawnPatrolTargetAcquiredEvent.class, this::handleSpawnPatrolTargetAcquiredEvent),
            of(SpawnPatrolTargetKilledEvent.class, this::handleSpawnPatrolTargetKilledEvent),
            of(SessionTimeLimitWarningEvent.class, this::handleSessionTimeLimitEvent),
            of(TasksCommandExecutedEvent.class, this::handleScheduledTaskCommandExecutedEvent)
        );
    }

    private void handleScheduledTaskCommandExecutedEvent(TasksCommandExecutedEvent event) {
        if (!CONFIG.client.extra.tasks.taskCommandExecutedNotification) return;
        sendEmbedMessage(Embed.builder()
            .title(Lang.t("Tarea Programada Ejecutada", "Scheduled Task Executed"))
            .addField(Lang.t("Comando", "Command"), "`" + event.command() + "`")
            .primaryColor());
    }

    public static String notificationMention() {
        return mentionRole(
            CONFIG.discord.notificationMentionRoleId.isEmpty()
                ? CONFIG.discord.accountOwnerRoleId
                : CONFIG.discord.notificationMentionRoleId
        );
    }

    private void handleSessionTimeLimitEvent(SessionTimeLimitWarningEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Aviso: Limite de Sesion", "Session Time Limit Warning"))
            .description(Lang.t("Expulsion en: ", "Kick in: ") + event.durationUntilKick().toMinutes() + "m")
            .primaryColor();
        if (CONFIG.client.extra.sessionTimeLimit.discordMentionPositions.contains((int) event.durationUntilKick().toMinutes())) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    private void handleSpawnPatrolTargetKilledEvent(SpawnPatrolTargetKilledEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Objetivo Eliminado", "Target Killed"))
            .addField(Lang.t("Objetivo", "Target"), "[" + event.profile().getName() + "](https://namemc.com/profile/" + event.profile().getId() + ")", false)
            .addField(Lang.t("Mensaje de Muerte", "Death Message"), escape(event.message())  , false)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.profile().getId()).toString())
            .successColor();
        sendEmbedMessage(embed);
    }

    private void handleSpawnPatrolTargetAcquiredEvent(SpawnPatrolTargetAcquiredEvent event) {
        var profile = event.targetProfile();
        var embed = Embed.builder()
            .title(Lang.t("Objetivo Adquirido", "Target Acquired"))
            .addField(Lang.t("Objetivo", "Target"), "[" + profile.getName() + "](https://namemc.com/profile/" + profile.getProfileId() + ")", false)
            .addField(Lang.t("Posicion", "Position"),getCoordinates(event.target()), false)
            .addField(Lang.t("Nuestra Posicion", "Our Position"), getCoordinates(CACHE.getPlayerCache().getThePlayer()), false)
            .addField(Lang.t("Distancia", "Distance"), String.format("%.2f", Math.sqrt(CACHE.getPlayerCache().distanceSqToSelf(event.target()))), false)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(profile.getProfileId()).toString())
            .primaryColor();
        sendEmbedMessage(embed);
    }

    public void handleConnectEvent(ClientConnectEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Conectado", "Connected"))
            .inQueueColor()
            .addField(Lang.t("Servidor", "Server"), CONFIG.client.server.address, true)
            .addField(Lang.t("IP del Proxy", "Proxy IP"), CONFIG.server.getProxyAddress(), false);
        if (CONFIG.discord.mentionRoleOnConnect) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
        updatePresence();
    }

    public void handlePlayerOnlineEvent(ClientOnlineEvent event) {
        var embedBuilder = Embed.builder()
            .title(Lang.t("En Linea", "Online"))
            .successColor();
        event.queueWait()
            .ifPresent(duration -> embedBuilder.addField(Lang.t("Duracion en Cola", "Queue Duration"), formatDuration(duration), true));
        if (CONFIG.discord.mentionRoleOnPlayerOnline) {
            sendEmbedMessage(notificationMention(), embedBuilder);
        } else {
            sendEmbedMessage(embedBuilder);
        }
    }

    private void handleClientConfigurationEnteringEvent(ClientConfigurationEvent.Entering event) {
        if (!CONFIG.client.extra.reconfiguringNotification) return;
        var embedBuilder = Embed.builder()
            .title(Lang.t("Reconfigurando...", "Reconfiguring..."))
            .inQueueColor();
        sendEmbedMessage(embedBuilder);
    }

    public void handleDisconnectEvent(ClientDisconnectEvent event) {
        var category = DisconnectReasonInfo.getDisconnectCategory(event.reason());
        var embed = Embed.builder()
            .title(Lang.t("Desconectado", "Disconnected"))
            .addField(Lang.t("Razon", "Reason"), event.reason(), false)
            .addField(Lang.t("Por que?", "Why?"), category.getWikiURL(), false)
            .addField(Lang.t("Categoria", "Category"), category.toString(), false)
            .addField(Lang.t("Duracion En Linea", "Online Duration"), formatDuration(event.onlineDurationWithQueueSkip()), false)
            .errorColor();
        if (Proxy.getInstance().isOn2b2t()) {
            switch (category) {
                case KICK -> {
                    if (!Proxy.getInstance().isPrio()) {
                        if (event.onlineDuration().toSeconds() >= 0L && event.onlineDuration().toSeconds() <= 1L) {
                            embed.description(Lang.t("""
                      Probablemente fuiste expulsado por alcanzar el limite de cuentas no-prio de 2b2t.
                      Considera configurar un proxy con el comando `clientConnection`.
                      O migra instancias de Gang'sProxy a multiples IPs.
                      """, """
                      You have likely been kicked for reaching the 2b2t non-prio account IP limit.
                      Consider configuring a connection proxy with the `clientConnection` command.
                      Or migrate Gang's proxy instances to multiple hosts/IP's.
                      """));
                        } else if (event.wasInQueue() && event.queuePosition() <= 1) {
                            embed.description(Lang.t("""
                      Probablemente fuiste expulsado por estar baneado por IP en 2b2t.

                      Para verificarlo, intenta conectarte con la misma cuenta desde una IP diferente.
                      """, """
                      You have likely been kicked due to being IP banned by 2b2t.

                      To check, try connecting and waiting through queue with the same account from a different IP.
                      """));
                        } else if (!event.wasInQueue()
                            && MathHelper.isInRange( // whether we were kicked at session time limit +- 30s
                            event.onlineDuration().toSeconds(),
                            MODULE.get(SessionTimeLimit.class).getSessionTimeLimit().toSeconds(), 30L)
                        ) {
                            embed.description(Lang.t("""
                        Probablemente fuiste expulsado por alcanzar el limite de sesion no-prio.

                        2b2t expulsa jugadores no-prio despues de %s horas en linea.
                        """, """
                        You have likely been kicked for reaching the non-prio session time limit.

                        2b2t kicks non-prio players after %s hours online.
                        """).formatted(MODULE.get(SessionTimeLimit.class).getSessionTimeLimit().toHours()));
                        } else if (!event.wasInQueue()
                            && MathHelper.isInRange( // whether we were kicked at 20 minutes +- 30s
                            event.onlineDuration().toSeconds(),
                            TimeUnit.MINUTES.toSeconds(20),
                            30L)
                        ) {
                            String msg = Lang.t("Posiblemente fuiste expulsado por el plugin AntiAFK de 2b2t", "You have possibly been kicked by 2b2t's AntiAFK plugin");
                            if (!MODULE.get(AntiAFK.class).isEnabled()) {
                                msg += "\n\nConsider enabling Gang'sProxy's AntiAFK module: `antiAFK on`";
                            }
                            embed.description(msg);
                        }
                    }
                }
                case CONNECTION_ISSUE, CONNECTION_ISSUE_PLAYER, CONNECTION_ISSUE_2B2T -> {
                    embed.addField(Lang.t("Estado 2b2t", "2b2t Status"), "https://status.2b2t.org/");
                }
            }
        }
        if (CONFIG.discord.mentionRoleOnDisconnect) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
        EXECUTOR.execute(this::updatePresence);
    }

    private void handleQueueWarning(QueueWarningEvent event) {
        sendEmbedMessage((event.mention() ? notificationMention() : ""), Embed.builder()
            .title(Lang.t("Aviso de Cola", "Queue Warning"))
            .addField(Lang.t("Posicion en Cola", "Queue Position"), "[" + Queue.queuePositionStr() + "]", false)
            .inQueueColor());
    }

    public void handleQueuePositionUpdateEvent(QueuePositionUpdateEvent event) {
        updatePresence();
    }

    public void handleAutoEatOutOfFoodEvent(final AutoEatOutOfFoodEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("AutoComer: Sin Comida", "AutoEat Out Of Food"))
            .description(Lang.t("Sin comida para AutoComer", "AutoEat threshold met but player has no food"))
            .errorColor();
        if (CONFIG.client.extra.autoEat.warningMention) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleQueueCompleteEvent(QueueCompleteEvent event) {
        updatePresence();
    }

    public void handleStartQueueEvent(QueueStartEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Cola Iniciada", "Started Queuing"))
            .inQueueColor()
            .addField(Lang.t("Cola Normal", "Regular Queue"), Queue.getQueueStatus().regular(), true)
            .addField(Lang.t("Cola Prioritaria", "Priority Queue"), Queue.getQueueStatus().prio(), true);
        if (event.wasOnline()) {
            embed
                .addField("Info", Lang.t("Expulsado a la cola", "Kicked to queue"), false)
                .addField(Lang.t("Duracion En Linea", "Online Duration"), formatDuration(event.wasOnlineDuration()), false);
        }
        if (CONFIG.discord.mentionRoleOnStartQueue) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
        updatePresence();
    }

    public void handleDeathEvent(ClientDeathEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Muerte del Jugador", "Player Death"))
            .errorColor()
            .addField(Lang.t("Coordenadas", "Coordinates"), getCoordinates(CACHE.getPlayerCache().getThePlayer()), false)
            .addField(Lang.t("Dimension", "Dimension"), World.getCurrentDimension().name(), false);
        if (CONFIG.discord.mentionRoleOnDeath) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleSelfDeathMessageEvent(ClientDeathMessageEvent event) {
        sendEmbedMessage(Embed.builder()
            .title(Lang.t("Mensaje de Muerte", "Death Message"))
            .errorColor()
            .addField(Lang.t("Mensaje", "Message"), event.message(), false));
    }

    public void handleHealthAutoDisconnectEvent(HealthAutoDisconnectEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("AutoDesconexion por Salud", "Health AutoDisconnect Triggered"))
            .addField(Lang.t("Salud", "Health"), CACHE.getPlayerCache().getThePlayer().getHealth(), true)
            .primaryColor();
        if (CONFIG.client.extra.utility.actions.autoDisconnect.mentionOnDisconnect) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleProxyClientConnectedEvent(PlayerConnectedEvent event) {
        if (!CONFIG.discord.clientConnectionMessages) return;
        var embed = Embed.builder()
            .title(Lang.t("Cliente Conectado", "Client Connected"))
            .addField(Lang.t("Nombre de Usuario", "Username"), escape(event.clientGameProfile().getName()), false)
            .addField(Lang.t("Version de MC", "MC Version"), event.session().getMCVersion(), false)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.clientGameProfile().getId()).toString())
            .primaryColor();
        if (CONFIG.discord.mentionOnClientConnected) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleProxyClientConnectedEventCheck2b2tMCVersionMatch(PlayerConnectedEvent event) {
        if (!CONFIG.discord.mcVersionMismatchWarning) return;
        if (!Proxy.getInstance().isOn2b2t() || !Proxy.getInstance().isConnected()) return;
        var client = Proxy.getInstance().getClient();
        if (client == null) return;
        var clientProtocolVersion = client.getProtocolVersion();
        var playerProtocolVersion = event.session().getProtocolVersion();
        if (!clientProtocolVersion.equalTo(playerProtocolVersion)) {
            var desc = Lang.t("""
                 **Version MC del Cliente**: %s
                 **Version MC de Gang'sProxy**: %s

                 Se recomienda usar la misma version de MC que Gang'sProxy.

                 De lo contrario puedes tener problemas con el anti-cheat de 2b2t.

                 O configura ViaVersion del cliente (reconecta tras el cambio):
                 `via zenithToServer version %s`
                 """, """
                 **Client MC Version**: %s
                 **Gang'sProxy Client MC Version**: %s

                 It is recommended to use the same MC version as the Gang'sProxy client.

                 Otherwise you may experience issues with 2b2t's anti-cheat.

                 Or configure Gang'sProxy's client ViaVersion (reconnect after changing):
                 `via zenithToServer version %s`
                 """).formatted(playerProtocolVersion.getName(), clientProtocolVersion.getName(), playerProtocolVersion.getName(), playerProtocolVersion.getName(), clientProtocolVersion.getName(), playerProtocolVersion.getName());
            if (CONFIG.client.viaversion.disableOn2b2t) {
                desc += Lang.t("`via zenithToServer disableOn2b2t off`\n", "`via zenithToServer disableOn2b2t off`\n");
            }
            if (!CONFIG.client.viaversion.enabled) {
                desc += Lang.t("`via zenithToServer on`\n", "`via zenithToServer on`\n");
            }
            var embed = Embed.builder()
                .title(Lang.t("Version de MC Incorrecta", "MC Version Mismatch"))
                .description(desc)
                .errorColor();
            var buttonId = "via-" + ThreadLocalRandom.current().nextInt(1000000);
            var button = Button.primary(buttonId, Lang.t("Auto-Configurar ViaVersion", "Auto-Configure ViaVersion"));
            Consumer<ButtonInteractionEvent> mapper = e -> {
                if (e.getComponentId().equals(buttonId)) {
                    CONFIG.client.viaversion.protocolVersion = playerProtocolVersion.getVersion();
                    CONFIG.client.viaversion.disableOn2b2t = false;
                    CONFIG.client.viaversion.enabled = true;
                    saveConfigAsync();
                    e.replyEmbeds(Embed.builder()
                            .title(Lang.t("ViaVersion Configurado", "ViaVersion Configured"))
                            .description(Lang.t("Los cambios se aplicaran en la proxima conexion", "Changes will take effect on next connect"))
                            .addField(Lang.t("Version de MC", "MC Version"), playerProtocolVersion.getName())
                            .primaryColor()
                            .toJDAEmbed())
                        .complete();
                }
            };
            sendEmbedMessageWithButtons(embed, List.of(button), mapper, Duration.ofHours(1L));
        }
    }

    public void handleProxySpectatorConnectedEvent(SpectatorConnectedEvent event) {
        if (!CONFIG.discord.clientConnectionMessages) return;
        var embed = Embed.builder()
            .title(Lang.t("Espectador Conectado", "Spectator Connected"))
            .addField(Lang.t("Nombre de Usuario", "Username"), escape(event.clientGameProfile().getName()), false)
            .addField(Lang.t("Version de MC", "MC Version"), event.session().getMCVersion(), false)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.clientGameProfile().getId()).toString())
            .primaryColor();
        if (CONFIG.discord.mentionOnSpectatorConnected) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleProxyClientDisconnectedEvent(PlayerDisconnectedEvent event) {
        if (!CONFIG.discord.clientConnectionMessages) return;
        var embed = Embed.builder()
            .title(Lang.t("Cliente Desconectado", "Client Disconnected"))
            .errorColor();
        if (nonNull(event.clientGameProfile())) {
            embed = embed.addField(Lang.t("Nombre de Usuario", "Username"), escape(event.clientGameProfile().getName()), false);
        }
        if (nonNull(event.reason())) {
            embed = embed.addField(Lang.t("Razon", "Reason"), escape(event.reason()), false);
        }
        if (CONFIG.discord.mentionOnClientDisconnected) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleVisualRangeEnterEvent(VisualRangeEnterEvent event) {
        var embedCreateSpec = Embed.builder()
            .title(Lang.t("Jugador en Rango Visual", "Player In Visual Range"))
            .color(event.isFriend() ? CONFIG.theme.success.color() : CONFIG.theme.error.color())
            .addField(Lang.t("Nombre del Jugador", "Player Name"), escape(event.playerEntry().getName()), true)
            .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.playerEntry().getProfileId() + "](https://namemc.com/profile/" + event.playerEntry().getProfileId() + ")"), true)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.playerEntry().getProfileId()).toString());

        if (CONFIG.discord.reportCoords) {
            embedCreateSpec.addField(Lang.t("Coordenadas", "Coordinates"), "||["
                + (int) event.playerEntity().getX() + ", "
                + (int) event.playerEntity().getY() + ", "
                + (int) event.playerEntity().getZ()
                + "]||", false);
        }
        final String buttonId = "addFriend" + ThreadLocalRandom.current().nextInt(1000000);
        final List<Button> buttons = asList(Button.primary(buttonId, Lang.t("Agregar Amigo", "Add Friend")));
        final Consumer<ButtonInteractionEvent> mapper = e -> {
            if (e.getComponentId().equals(buttonId)) {
                DISCORD_LOG.info("{} added friend: {} [{}]",
                    Optional.ofNullable(e.getInteraction().getMember())
                        .map(m -> m.getUser().getName())
                        .orElse("Unknown"),
                    event.playerEntry().getName(),
                    event.playerEntry().getProfileId());
                PLAYER_LISTS.getFriendsList().add(event.playerEntry().getName());
                e.replyEmbeds(Embed.builder()
                        .title(Lang.t("Amigo Anadido", "Friend Added"))
                        .successColor()
                        .addField(Lang.t("Nombre del Jugador", "Player Name"), escape(event.playerEntry().getName()), true)
                        .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.playerEntry().getProfileId() + "](https://namemc.com/profile/" + event.playerEntry().getProfileId() + ")"), true)
                        .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.playerEntry().getProfileId()).toString())
                        .toJDAEmbed())
                    .complete();
                saveConfigAsync();
            }
        };
        if (CONFIG.client.extra.visualRange.enterAlertMention)
            if (!event.isFriend())
                sendEmbedMessageWithButtons(notificationMention(), embedCreateSpec, buttons, mapper, Duration.ofHours(1));
            else
                sendEmbedMessage(embedCreateSpec);
        else
        if (!event.isFriend())
            sendEmbedMessageWithButtons(embedCreateSpec, buttons, mapper, Duration.ofHours(1));
        else
            sendEmbedMessage(embedCreateSpec);
    }

    public void handleVisualRangeLeaveEvent(final VisualRangeLeaveEvent event) {
        var embedCreateSpec = Embed.builder()
            .title(Lang.t("Jugador Salio del Rango Visual", "Player Left Visual Range"))
            .color(event.isFriend() ? CONFIG.theme.success.color() : CONFIG.theme.error.color())
            .addField(Lang.t("Nombre del Jugador", "Player Name"), escape(event.playerEntry().getName()), true)
            .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.playerEntity().getUuid() + "](https://namemc.com/profile/" + event.playerEntry().getProfileId() + ")"), true)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.playerEntity().getUuid()).toString());

        if (CONFIG.discord.reportCoords) {
            embedCreateSpec.addField(Lang.t("Coordenadas", "Coordinates"), "||["
                + (int) event.playerEntity().getX() + ", "
                + (int) event.playerEntity().getY() + ", "
                + (int) event.playerEntity().getZ()
                + "]||", false);
        }
        sendEmbedMessage(embedCreateSpec);
    }

    public void handleVisualRangeLogoutEvent(final VisualRangeLogoutEvent event) {
        var embedCreateSpec = Embed.builder()
            .title(Lang.t("Jugador Desconectado en Rango Visual", "Player Logout In Visual Range"))
            .color(event.isFriend() ? CONFIG.theme.success.color() : CONFIG.theme.error.color())
            .addField(Lang.t("Nombre del Jugador", "Player Name"), escape(event.playerEntry().getName()), true)
            .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.playerEntity().getUuid() + "](https://namemc.com/profile/" + event.playerEntry().getProfileId() + ")"), true)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.playerEntity().getUuid()).toString());

        if (CONFIG.discord.reportCoords) {
            embedCreateSpec.addField(Lang.t("Coordenadas", "Coordinates"), "||["
                + (int) event.playerEntity().getX() + ", "
                + (int) event.playerEntity().getY() + ", "
                + (int) event.playerEntity().getZ()
                + "]||", false);
        }
        sendEmbedMessage(embedCreateSpec);
    }

    public void handleNonWhitelistedPlayerConnectedEvent(NonWhitelistedPlayerConnectedEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Login no Permitido Bloqueado", "Non-Whitelisted Login Blocked"))
            .errorColor();
        if (nonNull(event.remoteAddress()) && CONFIG.discord.showNonWhitelistLoginIP) {
            embed = embed.addField(Lang.t("IP", "IP"), escape(event.remoteAddress().toString()), false);
        }
        if (nonNull(event.gameProfile()) && nonNull(event.gameProfile().getId()) && nonNull(event.gameProfile().getName())) {
            embed
                .addField(Lang.t("Nombre de Usuario", "Username"), escape(event.gameProfile().getName()), false)
                .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.gameProfile().getId().toString() + "](https://namemc.com/profile/" + event.gameProfile().getId().toString() + ")"), true)
                .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.gameProfile().getId()).toString());
            final String buttonId = "whitelist" + ThreadLocalRandom.current().nextInt(10000000);
            final List<Button> buttons = asList(Button.primary(buttonId, Lang.t("Agregar a Lista Blanca", "Whitelist Player")));
            final Consumer<ButtonInteractionEvent> mapper = e -> {
                if (e.getComponentId().equals(buttonId)) {
                    if (validateButtonInteractionEventFromAccountOwner(e)) {
                        DISCORD_LOG.info("{} whitelisted {} [{}]",
                            Optional.ofNullable(e.getInteraction().getMember()).map(m -> m.getUser().getName()).orElse("Unknown"),
                            event.gameProfile().getName(),
                            event.gameProfile().getId().toString());
                        PLAYER_LISTS.getWhitelist().add(event.gameProfile().getName());
                        e.replyEmbeds(Embed.builder()
                            .title(Lang.t("Jugador en Lista Blanca", "Player Whitelisted"))
                            .successColor()
                            .addField(Lang.t("Nombre del Jugador", "Player Name"), escape(event.gameProfile().getName()), true)
                            .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.gameProfile().getId().toString() + "](https://namemc.com/profile/" + event.gameProfile().getId().toString() + ")"), true)
                            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.gameProfile().getId()).toString())
                            .toJDAEmbed()).complete();
                        saveConfigAsync();
                    } else {
                        DISCORD_LOG.error("{} attempted to whitelist {} [{}] but was not authorized to do so!",
                            Optional.ofNullable(e.getInteraction().getMember()).map(m -> m.getUser().getName()).orElse("Unknown"),
                            event.gameProfile().getName(),
                            event.gameProfile().getId().toString());
                        e.replyEmbeds(Embed.builder()
                            .title(Lang.t("No Autorizado!", "Not Authorized!"))
                            .errorColor()
                            .addField(Lang.t("Error", "Error"),
                                Lang.t("Usuario: ", "User: ") + Optional.ofNullable(e.getInteraction().getMember()).map(m -> m.getUser().getName()).orElse("Unknown")
                                    + Lang.t(" no esta autorizado para ejecutar este comando. Contacta al propietario", " is not authorized to execute this command! Contact the account owner"), true)
                            .toJDAEmbed()).complete();
                    }
                }
            };
            sendEmbedMessageWithButtons(embed, buttons, mapper, Duration.ofHours(1L));
        } else { // shouldn't be possible if verifyUsers is enabled
            if (nonNull(event.gameProfile())) {
                embed
                    .addField(Lang.t("Nombre de Usuario", "Username"), escape(event.gameProfile().getName()), false);
            }
            if (CONFIG.discord.mentionOnNonWhitelistedClientConnected) {
                sendEmbedMessage(notificationMention(), embed);
            } else {
                sendEmbedMessage(embed);
            }
        }
    }

    private void handleBlacklistedPlayerConnectedEvent(BlacklistedPlayerConnectedEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Jugador en Lista Negra Desconectado", "Blacklisted Player Disconnected"))
            .errorColor();
        if (nonNull(event.remoteAddress()) && CONFIG.discord.showNonWhitelistLoginIP) {
            embed = embed.addField(Lang.t("IP", "IP"), escape(event.remoteAddress().toString()), false);
        }
        if (nonNull(event.gameProfile()) && nonNull(event.gameProfile().getId()) && nonNull(event.gameProfile().getName())) {
            embed
                .addField(Lang.t("Nombre de Usuario", "Username"), escape(event.gameProfile().getName()), false)
                .addField(Lang.t("UUID del Jugador", "Player UUID"), ("[" + event.gameProfile().getId().toString() + "](https://namemc.com/profile/" + event.gameProfile().getId().toString() + ")"), true)
                .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.gameProfile().getId()).toString());
        }
        if (CONFIG.discord.mentionOnNonWhitelistedClientConnected) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleProxySpectatorDisconnectedEvent(SpectatorDisconnectedEvent event) {
        if (!CONFIG.discord.clientConnectionMessages) return;
        var embed = Embed.builder()
            .title(Lang.t("Espectador Desconectado", "Spectator Disconnected"))
            .errorColor();
        if (nonNull(event.clientGameProfile())) {
            embed = embed.addField(Lang.t("Nombre de Usuario", "Username"), escape(event.clientGameProfile().getName()), false);
        }
        if (CONFIG.discord.mentionOnSpectatorDisconnected) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleActiveHoursConnectEvent(ActiveHoursConnectEvent event) {
        int queueLength;
        if (Proxy.getInstance().isPrio()) {
            queueLength = Queue.getQueueStatus().prio();
        } else {
            queueLength = Queue.getQueueStatus().regular();
        }
        var embed = Embed.builder()
            .title(Lang.t("Conexion por Horas Activas", "Active Hours Connect Triggered"))
            .addField(Lang.t("Tiempo Estimado", "ETA"), Queue.getQueueEta(queueLength), false)
            .primaryColor();
        if (event.willWait())
            embed.addField("Info", Lang.t("Esperando 1 minuto para evitar salto de cola", Lang.t("Esperando 1 minuto para evitar salto de cola", "Waiting 1 minute to avoid 2b2t reconnect queue skip")), false);
        sendEmbedMessage(embed);
    }

    private void handleDeathMessageChatEventKillMessage(DeathMessageChatEvent event) {
        if (!CONFIG.client.extra.killMessage) return;
        event.deathMessage().killer().ifPresent(killer -> {
            if (!killer.name().equals(CONFIG.authentication.username)) return;
            sendEmbedMessage(Embed.builder()
                .title(Lang.t("Eliminacion Detectada", "Kill Detected"))
                .primaryColor()
                .addField(Lang.t("Victima", "Victim"), escape(event.deathMessage().victim()), false)
                .addField(Lang.t("Mensaje", "Message"), escape(event.message()), false)
                .thumbnail(Proxy.getInstance().getPlayerHeadURL(event.deathMessage().victim()).toString()));
        });
    }

    public void handleServerPlayerConnectedEventStalk(ServerPlayerConnectedEvent event) {
        if (!CONFIG.client.extra.stalk.enabled || !PLAYER_LISTS.getStalkList().contains(event.playerEntry().getProfile())) return;
        sendEmbedMessage(notificationMention(), Embed.builder()
            .title(Lang.t("Jugador Vigilado En Linea!", "Stalked Player Online!"))
            .successColor()
            .addField(Lang.t("Nombre del Jugador", "Player Name"), event.playerEntry().getName(), true)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.playerEntry().getProfileId()).toString()));
    }

    public void handleServerPlayerDisconnectedEventStalk(ServerPlayerDisconnectedEvent event) {
        if (!CONFIG.client.extra.stalk.enabled || !PLAYER_LISTS.getStalkList().contains(event.playerEntry().getProfile())) return;
        sendEmbedMessage(notificationMention(), Embed.builder()
            .title(Lang.t("Jugador Vigilado Desconectado!", "Stalked Player Offline!"))
            .errorColor()
            .addField(Lang.t("Nombre del Jugador", "Player Name"), event.playerEntry().getName(), true)
            .thumbnail(Proxy.getInstance().getPlayerBodyURL(event.playerEntry().getProfileId()).toString()));
    }

    public void handleUpdateStartEvent(UpdateStartEvent event) {
        String verString = "Current Version: `" + escape(LAUNCH_CONFIG.version) + "`";
        var newVersion = event.newVersion();
        if (newVersion.isPresent()) verString += "\nNew Version: `" + escape(newVersion.get()) + "`";
        var embed = Embed.builder()
            .title(Lang.t("Actualizando y reiniciando...", "Updating and restarting..."))
            .description(verString)
            .primaryColor();
        if (!LAUNCH_CONFIG.auto_update) {
            embed
                .title(Lang.t("Reiniciando...", "Restarting..."))
                .addField(Lang.t("Error", "Error"), Lang.t("`autoUpdate` debe estar activado para aplicar nuevas actualizaciones", "`autoUpdate` must be enabled for new updates to apply"));
        };
        sendEmbedMessage(embed);
    }

    public void handleServerRestartingEvent(ServerRestartingEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Servidor Reiniciando", "Server Restarting"))
            .errorColor()
            .addField(Lang.t("Mensaje", "Message"), event.message(), true);
        if (CONFIG.discord.mentionRoleOnServerRestart) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleProxyLoginFailedEvent(ClientLoginFailedEvent event) {
        var description = Lang.t("""
        [Ayuda]
        Intenta esperar y conectarte de nuevo.

        Si falla, inicia sesion con el launcher vanilla de MC y unete a un servidor. Luego intenta de nuevo con Gang'sProxy.

        Otra posible causa es que tu cuenta de Microsoft necesite restablecer la contrasena.
        """, """
        [Help]
        Try waiting and connecting again.

        If that fails, log into the account with the vanilla MC launcher and join a server. Then try again with Gang'sProxy.

        Another possible cause is your microsoft account needing to have a password (re)set.
        """);
        if (event.exception() != null) {
            description = "Error: " + ChatUtil.constrainChatMessageSize(event.exception().getMessage(), true) + "\n\n" + description;
        }
        var embed = Embed.builder()
            .title(Lang.t("Inicio de Sesion Fallido", "Login Failed"))
            .description(description)
            .errorColor();
        if (CONFIG.discord.mentionRoleOnLoginFailed) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleStartConnectEvent(ClientStartConnectEvent event) {
        sendEmbedMessage(Embed.builder()
            .title(Lang.t("Conectando...", "Connecting..."))
            .inQueueColor());
    }

    public void handlePrioStatusUpdateEvent(PrioStatusUpdateEvent event) {
        if (!CONFIG.client.extra.prioStatusChangeMention) return;
        var embed = Embed.builder();
        if (event.prio()) {
            embed
                .title(Lang.t("Cola Prioritaria Detectada", "Prio Queue Status Detected"))
                .successColor();
        } else {
            embed
                .title(Lang.t("Cola Prioritaria Perdida", "Prio Queue Status Lost"))
                .errorColor();
        }
        embed.addField(Lang.t("Usuario", "User"), escape(CONFIG.authentication.username), false);
        if (CONFIG.discord.mentionRoleOnPrioUpdate) {
            sendEmbedMessage(notificationMention(), embed);
        } else {
            sendEmbedMessage(embed);
        }
    }

    public void handleAutoReconnectEvent(final AutoReconnectEvent event) {
        sendEmbedMessage(Embed.builder()
            .title(Lang.t("AutoReconectando en ", "AutoReconnecting in ") + event.delaySeconds() + "s")
            .inQueueColor());
    }

    public void handleMsaDeviceCodeLoginEvent(final MsaDeviceCodeLoginEvent event) {
        final var embed = Embed.builder()
            .title(Lang.t("Login con Codigo de Dispositivo", "Microsoft Device Code Login"))
            .primaryColor()
            .description(Lang.t("Inicia sesion aqui: ", "Login Here: ") + event.deviceCode().getDirectVerificationUri() + Lang.t(" \nCodigo: ", " \nCode: ") + event.deviceCode().getUserCode());
        if (CONFIG.discord.mentionRoleOnDeviceCodeAuth)
            sendEmbedMessage(notificationMention(), embed);
        else
            sendEmbedMessage(embed);
    }

    public void handleUpdateAvailableEvent(final UpdateAvailableEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Actualizacion Disponible!", "Update Available!"))
            .primaryColor();
        event.getVersion().ifPresent(v -> embed
            .addField(Lang.t("Actual", "Current"), "`" + escape(LAUNCH_CONFIG.version) + "`", false)
            .addField(Lang.t("Nueva", "New"), "`" + escape(v) + "`", false));
        embed.addField(
            "Info",
            Lang.t("Actualizacion se aplicara tras la proxima desconexion.\nO aplicar ahora: `update`", Lang.t("La actualizacion se aplicara tras la proxima desconexion.\nO aplicar ahora: `update`", "Update will be applied after the next disconnect.\nOr apply now: `update`")),
            false);
        sendEmbedMessage(embed);
    }

    public void handleReplayStartedEvent(final ReplayStartedEvent event) {
        sendEmbedMessage(Embed.builder()
            .title(Lang.t("Grabacion de Replay Iniciada", "Replay Recording Started"))
            .primaryColor());
    }

    public void handleReplayStoppedEvent(final ReplayStoppedEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Grabacion de Replay Detenida", "Replay Recording Stopped"))
            .primaryColor();
        var replayFile = event.replayFile();
        if (replayFile != null && CONFIG.client.extra.replayMod.sendRecordingsToDiscord) {
            try (InputStream in = new BufferedInputStream(new FileInputStream(replayFile))) {
                // 10mb discord file attachment size limit
                long replaySizeMb = replayFile.length() / (1024 * 1024);
                if (replaySizeMb > 10) {
                    if (CONFIG.client.extra.replayMod.fileIOUploadIfTooLarge) {
                        DISCORD_LOG.info("Uploading large replay to file.io with size: {}", replayFile.length());
                        var notiEmbed = Embed.builder()
                            .title(Lang.t("Grabacion de Replay Detenida", "Replay Recording Stopped"))
                            .description(Lang.t("Archivo de replay demasiado grande para Discord: " + replaySizeMb + "mb\nSubiendo a file.io...", "Replay file too large to upload directly to discord: " + replaySizeMb + "mb\nUpload to file.io in progress..."))
                            .inQueueColor();
                        sendEmbedMessage(notiEmbed);
                        var fileIOResponse = FileIOApi.INSTANCE.uploadFile(replayFile.getName(), in);
                        if (fileIOResponse.isEmpty() || !fileIOResponse.get().success()) {
                            embed.description(Lang.t("Error al subir a file.io y el replay es demasiado grande: " + replaySizeMb + "mb", "Failed uploading to file.io and replay too large to upload to discord: " + replaySizeMb + "mb"));
                        } else {
                            embed.description(Lang.t("Descargar `", "Download `") + replayFile.getName() + "`: " + fileIOResponse.get().link());
                        }
                    } else {
                        embed.description(Lang.t("Replay demasiado grande para Discord: " + replaySizeMb + "mb", "Replay too large to upload to discord: " + replaySizeMb + "mb"));
                    }
                } else {
                    embed.fileAttachment(new Embed.FileAttachment(replayFile.getName(), in.readAllBytes()));
                }
            } catch (final Exception e) {
                DISCORD_LOG.error("Failed to read replay file", e);
                embed.description(Lang.t("Error al leer el archivo de replay: ", "Error reading replay file: ") + e.getMessage());
            }
        }
        sendEmbedMessage(embed);
    }

    public void handleTotemPopEvent(final PlayerTotemPopAlertEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Totem del Jugador Activado", "Player Totem Popped"))
            .addField(Lang.t("Totems Restantes", "Totems Left"), event.totemsRemaining(), false)
            .errorColor();
        if (CONFIG.client.extra.autoTotem.totemPopAlertMention)
            sendEmbedMessage(notificationMention(), embed);
        else
            sendEmbedMessage(embed);
    }

    public void handleNoTotemsEvent(final NoTotemsEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Jugador Sin Totems", "Player Out of Totems"))
            .errorColor();
        if (CONFIG.client.extra.autoTotem.noTotemsAlertMention)
            sendEmbedMessage(notificationMention(), embed);
        else
            sendEmbedMessage(embed);
    }

    private void handlePluginLoadFailure(PluginLoadFailureEvent event) {
        String id = event.id() != null ? event.id() : "?";
        var embed = Embed.builder()
            .title(Lang.t("Error al Cargar Plugin", "Plugin Load Failure"))
            .errorColor()
            .description(Lang.t("Error: ", "Error: ") + escape(event.message()))
            .addField(Lang.t("ID del Plugin", "Plugin ID"), escape(id), false)
            .addField(Lang.t("Jar del Plugin", "Plugin Jar"), escape(event.jarPath().getFileName().toString()), false);
        sendEmbedMessage(embed);
    }

    private void handlePluginLoadedEvent(PluginLoadedEvent event) {
        var embed = Embed.builder()
            .title(Lang.t("Plugin Cargado", "Plugin Loaded"))
            .successColor()
            .addField("ID", escape(event.pluginInfo().id()), false)
            .addField(Lang.t("Descripcion", "Description"), escape(event.pluginInfo().description()))
            .addField(Lang.t("Version", "Version"), escape(event.pluginInfo().version().toString()), false)
            .addField("URL", escape(event.pluginInfo().url()), false)
            .addField(Lang.t("Autor(es)", "Author(s)"), String.join(", ", event.pluginInfo().authors()), false);
        sendEmbedMessage(embed);
    }

    /**
     * Convenience proxy methods
     */
    public void sendEmbedMessage(Embed embed) {
        DISCORD.sendEmbedMessage(embed);
    }
    public void sendEmbedMessage(String message, Embed embed) {
        DISCORD.sendEmbedMessage(message, embed);
    }
    public void sendMessage(final String message) {
        DISCORD.sendMessage(message);
    }
    void sendEmbedMessageWithButtons(String message, Embed embed, List<Button> buttons, Consumer<ButtonInteractionEvent> mapper, Duration timeout) {
        DISCORD.sendEmbedMessageWithButtons(message, embed, buttons, mapper, timeout);
    }
    void sendEmbedMessageWithButtons(Embed embed, List<Button> buttons, Consumer<ButtonInteractionEvent> mapper, Duration timeout) {
        DISCORD.sendEmbedMessageWithButtons(embed, buttons, mapper, timeout);
    }
    public void updatePresence(final OnlineStatus onlineStatus, final Activity activity) {
        DISCORD.setPresence(onlineStatus, activity);
    }
    public void updatePresence() {
        DISCORD.tickPresence();
    }
}
